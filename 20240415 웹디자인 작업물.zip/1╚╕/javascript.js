$(document).ready(function(){
    $('.navi>li').mouseover(function(){
        $(this).find('.submenu').stop().slideDown(500);
    }).mouseoust(function(){
        $(this).find('.submenu').stop().sildeUp(500)
    });
});
    
    $('.imgslide a:gt(0)').hide();
    setInterval(function(){
        $('.imgslide a:first-child')
        .fadeOut(1000)
        .next('a')
        .fadeIn(1000)
        .end()
        .appendTo('.imgslide');
    },3000);
    
    $(".notice li:first").click(function(){
        $("#modal").addClass("active");
    });
    $(".btn").click(function(){
        $("#modal").removeClass("active")
    });